# SeaFree GPS (stage 1)

Lightweight offline marine GPS app. Kotlin, Jetpack Compose, platform LocationManager (no Google Play Services).
GPS position only: not a chart plotter, not a certified navigation system.

## Status
Stage 1 (this download): app shell with the 11-item side menu, permission flow, and the full GPS Info screen
(position decimal and deg/min, SOG, COG, trip distance/avg/max, accuracy, satellites, local and GPS UTC time),
plus unit tests for the GPS maths. Other screens are placeholders.
NOT yet compiled or run: the authoring environment had no Android SDK or internet. Expect to fix small
build errors on first sync.

## Build (free tools only)
1. Install Android Studio (current stable) with JDK 17 and SDK Platform 35.
2. File > Open > select this folder, let Gradle sync (needs internet once for dependencies).
   Android Studio creates the Gradle wrapper for you. Command line alternative: install Gradle 8.9, run `gradle wrapper`.
3. Unit tests: `./gradlew testDebugUnitTest`
4. Debug APK: `./gradlew assembleDebug` -> app/build/outputs/apk/debug/app-debug.apk
5. Install: enable USB debugging, `adb install -r app-debug.apk` (the -r flag updates in place, keeping data).

## Signed release APK (preview)
Create a keystore once: `keytool -genkey -v -keystore seafree.jks -keyalg RSA -keysize 2048 -validity 10000 -alias seafree`
Keep it and its passwords safe and never commit it: you need the same key for every update. Then in Android Studio:
Build > Generate Signed App Bundle / APK > APK > release. (Signing config via gradle comes in stage 5.)

## Behaviour notes
- Nothing fake is shown: no fix means "--". After 10 s without a fix, speed and course are hidden and the position is labelled last known.
- COG is hidden below about 0.5 kn because GPS bearing is unreliable at rest.
- GPS runs only while the app is visible (no background service, no background location permission).
- Trip statistics: fixes worse than 50 m are ignored; distance counts only after moving further than max(3 m, accuracy/2).

## Build plan
2. Room DB, waypoints, MOB, routes, Zoom (large readout + compass)
3. Trip recording (foreground service, justified at that point), speed graph, GPX/CSV export and import
4. Offline map
5. Settings, Help and Safety, Storage Manager, backup/restore, release signing

package app.seafree.gps.core

import org.junit.Assert.assertEquals
import org.junit.Test

class TripStatsTest {
    private val metersPerDegLat = 111_194.93

    private fun fix(i: Int, northM: Double, speed: Float? = 5f, acc: Float? = 5f, timeMs: Long = i * 1000L) =
        TrackFix(northM / metersPerDegLat, 0.0, timeMs, acc, speed)

    @Test fun steadyMovementAccumulatesDistanceAndSpeeds() {
        val t = TripStats()
        for (i in 0 until 60) t.onFix(fix(i, i * 5.0))
        val s = t.snapshot
        assertEquals(295.0, s.distanceM, 0.5)
        assertEquals(5.0, s.avgSpeedMps, 0.01)
        assertEquals(5.0, s.maxSpeedMps, 0.01)
    }

    @Test fun stationaryJitterAddsNoDistance() {
        val t = TripStats()
        for (i in 0 until 30) t.onFix(fix(i, if (i % 2 == 0) 0.0 else 1.0, speed = 0f, acc = 3f))
        assertEquals(0.0, t.snapshot.distanceM, 1e-9)
        assertEquals(0L, t.snapshot.movingTimeMs)
    }

    @Test fun poorAccuracyFixesAreIgnored() {
        val t = TripStats()
        for (i in 0 until 5) t.onFix(fix(i, i * 5.0, acc = 100f))
        assertEquals(0.0, t.snapshot.distanceM, 1e-9)
    }

    @Test fun duplicateTimestampIsIgnored() {
        val t = TripStats()
        t.onFix(fix(0, 0.0))
        t.onFix(fix(1, 5.0))
        t.onFix(fix(1, 10.0, timeMs = 1000L))
        assertEquals(5.0, t.snapshot.distanceM, 0.01)
    }

    @Test fun implausibleJumpReAnchorsWithoutAddingDistance() {
        val t = TripStats()
        t.onFix(TrackFix(0.0, 0.0, 0L, 5f, 5f))
        t.onFix(TrackFix(1.0, 0.0, 1000L, 5f, 5f))
        assertEquals(0.0, t.snapshot.distanceM, 1e-9)
        t.onFix(TrackFix(1.0 + 5.0 / metersPerDegLat, 0.0, 2000L, 5f, 5f))
        assertEquals(5.0, t.snapshot.distanceM, 0.01)
    }

    @Test fun resetClearsEverything() {
        val t = TripStats()
        for (i in 0 until 10) t.onFix(fix(i, i * 5.0))
        t.reset()
        assertEquals(0.0, t.snapshot.distanceM, 1e-9)
        assertEquals(0.0, t.snapshot.maxSpeedMps, 1e-9)
    }
}

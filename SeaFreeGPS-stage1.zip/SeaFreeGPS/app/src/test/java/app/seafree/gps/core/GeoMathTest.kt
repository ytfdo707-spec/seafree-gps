package app.seafree.gps.core

import org.junit.Assert.assertEquals
import org.junit.Test

class GeoMathTest {
    @Test fun oneDegreeOfLatitudeIsAboutSixtyNauticalMiles() {
        val m = GeoMath.distanceMeters(0.0, 0.0, 1.0, 0.0)
        assertEquals(60.04, GeoMath.metersToNm(m), 0.05)
    }

    @Test fun zeroDistanceForSamePoint() {
        assertEquals(0.0, GeoMath.distanceMeters(21.5, 39.2, 21.5, 39.2), 1e-9)
    }

    @Test fun bearingsOnCardinalDirections() {
        assertEquals(0.0, GeoMath.bearingDegrees(0.0, 0.0, 1.0, 0.0), 1e-6)
        assertEquals(90.0, GeoMath.bearingDegrees(0.0, 0.0, 0.0, 1.0), 1e-6)
        assertEquals(180.0, GeoMath.bearingDegrees(0.0, 0.0, -1.0, 0.0), 1e-6)
        assertEquals(270.0, GeoMath.bearingDegrees(0.0, 0.0, 0.0, -1.0), 1e-6)
    }

    @Test fun normalizeDegrees() {
        assertEquals(270.0, GeoMath.normalizeDegrees(-90.0), 1e-9)
        assertEquals(0.0, GeoMath.normalizeDegrees(360.0), 1e-9)
        assertEquals(5.0, GeoMath.normalizeDegrees(725.0), 1e-9)
    }

    @Test fun unitConversions() {
        assertEquals(1.0, GeoMath.metersToNm(1852.0), 1e-12)
        assertEquals(1.0, GeoMath.mpsToKnots(1852.0 / 3600.0), 1e-12)
    }

    @Test fun cardinalPoints() {
        assertEquals("N", GeoMath.cardinal(0.0))
        assertEquals("N", GeoMath.cardinal(359.0))
        assertEquals("NE", GeoMath.cardinal(45.0))
        assertEquals("S", GeoMath.cardinal(180.0))
        assertEquals("W", GeoMath.cardinal(270.0))
    }

    @Test fun coordinateFormatting() {
        assertEquals("12.34568° N", GeoMath.formatDecimal(12.345678, true))
        assertEquals("45.50000° W", GeoMath.formatDecimal(-45.5, false))
        assertEquals("12° 20.741' N", GeoMath.formatDegMin(12.345678, true))
        assertEquals("045° 30.000' W", GeoMath.formatDegMin(-45.5, false))
    }

    @Test fun degMinRoundingCarries() {
        assertEquals("11° 00.000' N", GeoMath.formatDegMin(10.99999999, true))
    }
}

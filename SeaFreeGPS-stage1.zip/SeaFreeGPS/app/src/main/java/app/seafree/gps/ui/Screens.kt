package app.seafree.gps.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp

/** [stage] is the planned build stage in which the screen is implemented. */
enum class Screen(val title: String, val icon: ImageVector, val stage: Int, val plan: String) {
    GPS_INFO("GPS Info", Icons.Default.Home, 1, "Live position, speed, course and trip statistics."),
    SPEED_GRAPH("Speed and GPS Graph", Icons.Default.List, 3, "Speed and accuracy over time from the recorded track."),
    MOB("MOB", Icons.Default.Warning, 2, "Save the incident position and show bearing and distance back to it."),
    ZOOM("Zoom", Icons.Default.Search, 2, "Very large speed, course and compass readout."),
    ROUTE("Route", Icons.Default.Send, 2, "Create, save and follow routes between waypoints."),
    WAYPOINTS("Waypoints", Icons.Default.Place, 2, "Save, name, edit and navigate to waypoints."),
    OFFLINE_MAP("Offline Map", Icons.Default.LocationOn, 4, "Download and view selected map areas."),
    TRIP("Regatta / Trip Tracking", Icons.Default.PlayArrow, 3, "Start, pause, resume and stop track recording; GPX/CSV export."),
    SETTINGS("Settings", Icons.Default.Settings, 5, "Units, recording interval, night mode."),
    HELP("Help and Safety", Icons.Default.Info, 5, "Usage help and safety limitations."),
    STORAGE("Storage Manager", Icons.Default.Delete, 5, "Storage by category, deletion, GPX/CSV backup and restore."),
}

@Composable
fun ComingSoonScreen(screen: Screen) {
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text(screen.title, style = MaterialTheme.typography.headlineMedium)
        Text("Planned for build stage ${screen.stage}.", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
        Text(screen.plan, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(top = 8.dp))
    }
}

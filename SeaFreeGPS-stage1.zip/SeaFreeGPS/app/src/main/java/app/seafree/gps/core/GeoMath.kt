package app.seafree.gps.core

import java.util.Locale
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** Pure-Kotlin geodesy helpers (no Android classes, so they are unit-testable on the JVM). */
object GeoMath {
    const val EARTH_RADIUS_M = 6_371_008.8
    const val METERS_PER_NM = 1852.0
    const val MPS_TO_KNOTS = 3600.0 / METERS_PER_NM

    /** Great-circle (haversine) distance in metres. */
    fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val p1 = Math.toRadians(lat1)
        val p2 = Math.toRadians(lat2)
        val dp = p2 - p1
        val dl = Math.toRadians(lon2 - lon1)
        val a = sin(dp / 2).pow(2) + cos(p1) * cos(p2) * sin(dl / 2).pow(2)
        return 2 * EARTH_RADIUS_M * asin(min(1.0, sqrt(a)))
    }

    /** Initial true bearing from point 1 to point 2, in [0, 360). */
    fun bearingDegrees(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val p1 = Math.toRadians(lat1)
        val p2 = Math.toRadians(lat2)
        val dl = Math.toRadians(lon2 - lon1)
        val y = sin(dl) * cos(p2)
        val x = cos(p1) * sin(p2) - sin(p1) * cos(p2) * cos(dl)
        return normalizeDegrees(Math.toDegrees(atan2(y, x)))
    }

    fun normalizeDegrees(deg: Double): Double {
        val r = deg % 360.0
        val n = (if (r < 0) r + 360.0 else r) + 0.0
        return if (n >= 360.0) 0.0 else n
    }

    fun metersToNm(m: Double): Double = m / METERS_PER_NM
    fun mpsToKnots(mps: Double): Double = mps * MPS_TO_KNOTS

    fun cardinal(deg: Double): String {
        val names = arrayOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
        return names[((normalizeDegrees(deg) + 22.5) / 45.0).toInt() % 8]
    }

    private fun hemisphere(value: Double, isLatitude: Boolean): String =
        if (isLatitude) (if (value >= 0) "N" else "S") else (if (value >= 0) "E" else "W")

    /** e.g. 12.34568° N */
    fun formatDecimal(value: Double, isLatitude: Boolean): String =
        String.format(Locale.US, "%.5f° %s", abs(value), hemisphere(value, isLatitude))

    /** e.g. 12° 20.741' N (minutes rounded to 0.001, carry handled). */
    fun formatDegMin(value: Double, isLatitude: Boolean): String {
        val a = abs(value)
        var deg = floor(a).toInt()
        var minutes = Math.round((a - deg) * 60.0 * 1000.0) / 1000.0
        if (minutes >= 60.0) {
            deg += 1
            minutes = 0.0
        }
        val hemi = hemisphere(value, isLatitude)
        return if (isLatitude) {
            String.format(Locale.US, "%02d° %06.3f' %s", deg, minutes, hemi)
        } else {
            String.format(Locale.US, "%03d° %06.3f' %s", deg, minutes, hemi)
        }
    }
}

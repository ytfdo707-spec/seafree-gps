package app.seafree.gps.core

import kotlin.math.max
import kotlin.math.min

/** A single position fix, independent of the Android Location class. */
data class TrackFix(
    val lat: Double,
    val lon: Double,
    val timeMs: Long,
    val accuracyM: Float?,
    val speedMps: Float?,
)

data class TripSnapshot(
    val distanceM: Double = 0.0,
    val movingTimeMs: Long = 0L,
    val maxSpeedMps: Double = 0.0,
) {
    /** Average speed while moving (distance / moving time). 0 when there is no moving time. */
    val avgSpeedMps: Double
        get() = if (movingTimeMs > 0) distanceM / (movingTimeMs / 1000.0) else 0.0
}

/**
 * Accumulates trip distance and speeds with basic noise filtering:
 *  - fixes worse than [maxAccuracyM] are ignored
 *  - fixes with non-increasing timestamps are ignored
 *  - distance only counts once the position moved further than max([minStepM], accuracy/2)
 *    from the last counted point (stops GPS jitter adding distance while stationary)
 *  - jumps implying more than [maxPlausibleSpeedMps] re-anchor without adding distance
 */
class TripStats(
    private val maxAccuracyM: Float = 50f,
    private val minStepM: Double = 3.0,
    private val maxPlausibleSpeedMps: Double = 60.0,
    private val movingThresholdMps: Double = 0.26, // about 0.5 knots
) {
    var snapshot: TripSnapshot = TripSnapshot()
        private set

    private var anchor: TrackFix? = null
    private var lastTimeMs: Long = 0L

    fun reset() {
        snapshot = TripSnapshot()
        anchor = null
        lastTimeMs = 0L
    }

    fun onFix(fix: TrackFix): TripSnapshot {
        val acc = fix.accuracyM
        if (acc != null && acc > maxAccuracyM) return snapshot

        val a = anchor
        if (a == null) {
            anchor = fix
            lastTimeMs = fix.timeMs
            return snapshot
        }

        val dtLastMs = fix.timeMs - lastTimeMs
        if (dtLastMs <= 0) return snapshot
        lastTimeMs = fix.timeMs

        val d = GeoMath.distanceMeters(a.lat, a.lon, fix.lat, fix.lon)
        val dtAnchorS = (fix.timeMs - a.timeMs) / 1000.0
        val implied = d / dtAnchorS
        if (implied > maxPlausibleSpeedMps) {
            anchor = fix
            return snapshot
        }

        val speed = fix.speedMps?.toDouble() ?: implied
        var moving = snapshot.movingTimeMs
        var maxSpeed = snapshot.maxSpeedMps
        var dist = snapshot.distanceM

        if (speed >= movingThresholdMps) moving += min(dtLastMs, 10_000L)
        if (speed <= maxPlausibleSpeedMps) maxSpeed = max(maxSpeed, speed)

        val threshold = max(minStepM, (acc ?: 0f) * 0.5)
        if (d >= threshold) {
            dist += d
            anchor = fix
        }
        snapshot = TripSnapshot(dist, moving, maxSpeed)
        return snapshot
    }
}

package app.seafree.gps.gps

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import android.location.GnssStatus
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.AndroidViewModel
import app.seafree.gps.core.TrackFix
import app.seafree.gps.core.TripSnapshot
import app.seafree.gps.core.TripStats
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Foreground-only GPS updates using the platform LocationManager (no Google Play Services,
 * so it also works on devices without them). Updates run only while the app is visible.
 */
class GpsViewModel(app: Application) : AndroidViewModel(app) {

    private val lm = app.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private val tripStats = TripStats()
    private val _state = MutableStateFlow(GpsUiState())
    val state: StateFlow<GpsUiState> = _state.asStateFlow()

    private val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) = handle(location)

        override fun onProviderEnabled(provider: String) {
            if (provider == LocationManager.GPS_PROVIDER) _state.update { it.copy(gpsEnabled = true) }
        }

        override fun onProviderDisabled(provider: String) {
            if (provider == LocationManager.GPS_PROVIDER) _state.update { it.copy(gpsEnabled = false) }
        }

        @Suppress("OVERRIDE_DEPRECATION")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit
    }

    private val gnssCallback = object : GnssStatus.Callback() {
        override fun onSatelliteStatusChanged(status: GnssStatus) {
            var used = 0
            for (i in 0 until status.satelliteCount) if (status.usedInFix(i)) used++
            _state.update { it.copy(satUsed = used, satVisible = status.satelliteCount) }
        }

        override fun onStopped() {
            _state.update { it.copy(satUsed = null, satVisible = null) }
        }
    }

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    fun start() {
        if (_state.value.running) return
        try {
            lm.requestLocationUpdates(
                LocationManager.GPS_PROVIDER, UPDATE_INTERVAL_MS, 0f, listener, Looper.getMainLooper(),
            )
            lm.registerGnssStatusCallback(gnssCallback, Handler(Looper.getMainLooper()))
            _state.update {
                it.copy(
                    running = true,
                    noGpsHardware = false,
                    gpsEnabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER),
                )
            }
        } catch (e: IllegalArgumentException) {
            _state.update { it.copy(running = false, noGpsHardware = true) }
        } catch (e: SecurityException) {
            _state.update { it.copy(running = false) }
        }
    }

    fun stop() {
        if (!_state.value.running) return
        lm.removeUpdates(listener)
        lm.unregisterGnssStatusCallback(gnssCallback)
        _state.update { it.copy(running = false, satUsed = null, satVisible = null) }
    }

    fun resetTrip() {
        tripStats.reset()
        _state.update { it.copy(trip = TripSnapshot()) }
    }

    private fun handle(location: Location) {
        val speed = if (location.hasSpeed()) location.speed else null
        val acc = if (location.hasAccuracy()) location.accuracy else null
        // Course over ground is meaningless when (almost) stationary, so hide it.
        val bearing = if (location.hasBearing() && (speed ?: 0f) >= MIN_COURSE_SPEED_MPS) location.bearing else null
        val fix = GpsFix(
            lat = location.latitude,
            lon = location.longitude,
            timeUtcMs = location.time,
            elapsedRealtimeMs = location.elapsedRealtimeMillis,
            accuracyM = acc,
            speedMps = speed,
            bearingDeg = bearing,
        )
        val trip = tripStats.onFix(TrackFix(fix.lat, fix.lon, fix.timeUtcMs, acc, speed))
        _state.update { it.copy(fix = fix, trip = trip, gpsEnabled = true) }
    }

    override fun onCleared() {
        stop()
    }

    private companion object {
        const val UPDATE_INTERVAL_MS = 1000L
        const val MIN_COURSE_SPEED_MPS = 0.26f // about 0.5 knots
    }
}

package app.seafree.gps.gps

import app.seafree.gps.core.TripSnapshot

data class GpsFix(
    val lat: Double,
    val lon: Double,
    val timeUtcMs: Long,
    val elapsedRealtimeMs: Long,
    val accuracyM: Float?,
    /** Null when the receiver reports no speed. */
    val speedMps: Float?,
    /** Null when no bearing is reported or the boat is nearly stationary (bearing unreliable). */
    val bearingDeg: Float?,
)

data class GpsUiState(
    val running: Boolean = false,
    val gpsEnabled: Boolean = true,
    val noGpsHardware: Boolean = false,
    val fix: GpsFix? = null,
    val satUsed: Int? = null,
    val satVisible: Int? = null,
    val trip: TripSnapshot = TripSnapshot(),
)

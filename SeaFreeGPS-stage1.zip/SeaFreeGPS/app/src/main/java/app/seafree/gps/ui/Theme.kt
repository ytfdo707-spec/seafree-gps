package app.seafree.gps.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val StatusOk = Color(0xFF1B7F3B)
val StatusWarn = Color(0xFFB26A00)
val StatusBad = Color(0xFFB3261E)
val MobRed = Color(0xFFD32F2F)

private val Navy = Color(0xFF0A2342)

private val LightColors = lightColorScheme(
    primary = Navy,
    onPrimary = Color.White,
    background = Color(0xFFD7F3F5),
    onBackground = Navy,
    surface = Color.White,
    onSurface = Navy,
    onSurfaceVariant = Color(0xFF3B5470),
    outline = Navy,
    secondaryContainer = Color(0xFFB8E6EA),
    onSecondaryContainer = Navy,
    error = StatusBad,
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF7FD6E0),
    onPrimary = Color(0xFF05212A),
    background = Color(0xFF050D1A),
    onBackground = Color(0xFFE4F0FF),
    surface = Color(0xFF0E1C33),
    onSurface = Color(0xFFE4F0FF),
    onSurfaceVariant = Color(0xFF9DB8D4),
    outline = Color(0xFF4F7FA8),
    secondaryContainer = Color(0xFF1B3A5C),
    onSecondaryContainer = Color(0xFFE4F0FF),
    error = Color(0xFFFFB4AB),
)

@Composable
fun SeaFreeTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (darkTheme) DarkColors else LightColors, content = content)
}

package app.seafree.gps.gps

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner

fun hasFineLocation(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
        PackageManager.PERMISSION_GRANTED

class LocationPermissionState(granted: Boolean) {
    var granted by mutableStateOf(granted)
    var askedOnce by mutableStateOf(false)
    var request: () -> Unit = {}
}

@Composable
fun rememberLocationPermission(): LocationPermissionState {
    val context = LocalContext.current
    val state = remember { LocationPermissionState(hasFineLocation(context)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        state.granted = result[Manifest.permission.ACCESS_FINE_LOCATION] == true || hasFineLocation(context)
        state.askedOnce = true
    }
    state.request = {
        launcher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }
    return state
}

/** Runs GPS updates only while the app is visible (ON_START to ON_STOP) and permission is granted. */
@Composable
fun GpsLifecycleEffect(vm: GpsViewModel, perm: LocationPermissionState) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner, perm.granted) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> {
                    val g = hasFineLocation(context)
                    if (g != perm.granted) perm.granted = g
                    if (g) vm.start()
                }
                Lifecycle.Event.ON_STOP -> vm.stop()
                else -> Unit
            }
        }
        owner.lifecycle.addObserver(observer)
        onDispose {
            owner.lifecycle.removeObserver(observer)
            vm.stop()
        }
    }
}

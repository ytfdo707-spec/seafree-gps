package app.seafree.gps

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import app.seafree.gps.ui.SeaFreeApp
import app.seafree.gps.ui.SeaFreeTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { SeaFreeTheme { SeaFreeApp() } }
    }
}

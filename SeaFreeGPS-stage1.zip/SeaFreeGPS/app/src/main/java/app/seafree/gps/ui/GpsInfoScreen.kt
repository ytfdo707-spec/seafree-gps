package app.seafree.gps.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.SystemClock
import android.provider.Settings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.seafree.gps.core.GeoMath
import app.seafree.gps.core.TripSnapshot
import app.seafree.gps.gps.GpsFix
import app.seafree.gps.gps.GpsUiState
import app.seafree.gps.gps.LocationPermissionState
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.roundToInt

private const val STALE_MS = 10_000L
private const val WEAK_ACCURACY_M = 25f

private data class Tick(val wallMs: Long, val elapsedMs: Long)

@Composable
private fun rememberTick(): State<Tick> =
    produceState(Tick(System.currentTimeMillis(), SystemClock.elapsedRealtime())) {
        while (true) {
            delay(1000)
            value = Tick(System.currentTimeMillis(), SystemClock.elapsedRealtime())
        }
    }

@Composable
fun GpsInfoScreen(state: GpsUiState, perm: LocationPermissionState, onResetTrip: () -> Unit) {
    if (perm.granted) GpsDashboard(state, onResetTrip) else PermissionPrompt(perm)
}

@Composable
private fun PermissionPrompt(perm: LocationPermissionState) {
    val context = LocalContext.current
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        InfoCard("Location permission needed") {
            Text(
                "SeaFree GPS needs precise location to show your position, speed and course from " +
                    "your phone's GPS receiver. Location data stays on this device. Basic GPS needs " +
                    "no internet connection and no account.",
                style = MaterialTheme.typography.bodyLarge,
            )
            if (perm.askedOnce) {
                Spacer(Modifier.height(12.dp))
                Text(
                    "Permission was not granted, so the GPS screens cannot show your position. " +
                        "If the system dialog no longer appears, enable Location in the app settings.",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyLarge,
                )
            }
            Spacer(Modifier.height(16.dp))
            BigButton("Allow location") { perm.request() }
            if (perm.askedOnce) {
                Spacer(Modifier.height(8.dp))
                BigButton("Open app settings", outlined = true) {
                    context.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    )
                }
            }
        }
    }
}

@Composable
private fun GpsDashboard(state: GpsUiState, onResetTrip: () -> Unit) {
    val context = LocalContext.current
    val tick by rememberTick()
    val fix = state.fix
    val ageMs = fix?.let { (tick.elapsedMs - it.elapsedRealtimeMs).coerceAtLeast(0L) }
    val live = fix != null && ageMs != null && ageMs <= STALE_MS
    var confirmReset by remember { mutableStateOf(false) }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 600.dp
        val bigSp = if (wide) 72.sp else 48.sp

        val speedAndCourse: @Composable () -> Unit = {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SpeedCard(if (live) fix?.speedMps else null, bigSp, Modifier.weight(1f))
                CourseCard(if (live) fix else null, bigSp, Modifier.weight(1f))
            }
        }
        val position: @Composable () -> Unit = { CoordsCard(fix, live, ageMs) }
        val trip: @Composable () -> Unit = { TripCard(state.trip) { confirmReset = true } }
        val status: @Composable () -> Unit = { TimeStatusCard(fix, tick.wallMs, state) }

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            StatusBanner(state, fix, ageMs)
            if (!state.gpsEnabled && !state.noGpsHardware) {
                BigButton("Open location settings") {
                    context.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
            if (wide) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        speedAndCourse()
                        status()
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        position()
                        trip()
                    }
                }
            } else {
                speedAndCourse()
                position()
                trip()
                status()
            }
            Text(
                "GPS position only. SeaFree GPS is not a chart plotter or a certified marine " +
                    "navigation system. Do not rely on it as your only means of navigation or " +
                    "emergency communication. GPS may be inaccurate or unavailable offshore.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Reset trip statistics?") },
            text = { Text("This clears the current trip distance, average speed and maximum speed.") },
            confirmButton = {
                TextButton(onClick = { confirmReset = false; onResetTrip() }) { Text("Reset") }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun StatusBanner(state: GpsUiState, fix: GpsFix?, ageMs: Long?) {
    val acc = fix?.accuracyM
    val (text, color) = when {
        state.noGpsHardware -> "No GPS receiver found on this device." to StatusBad
        !state.gpsEnabled -> "GPS is turned off. Turn on Location to get a fix." to StatusBad
        fix == null || ageMs == null -> "Searching for GPS signal. Move to a spot with open sky." to StatusWarn
        ageMs > STALE_MS -> "Signal lost. Last fix ${ageMs / 1000} s ago. Live values are hidden." to StatusBad
        acc != null && acc > WEAK_ACCURACY_M -> "Weak signal. Accuracy about ±${acc.roundToInt()} m." to StatusWarn
        acc != null -> "GPS fix. Accuracy about ±${acc.roundToInt()} m." to StatusOk
        else -> "GPS fix." to StatusOk
    }
    Surface(color = color, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
        Text(
            text,
            color = Color.White,
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
        )
    }
}

@Composable
private fun SpeedCard(speedMps: Float?, bigSp: androidx.compose.ui.unit.TextUnit, modifier: Modifier) {
    InfoCard("SPEED (SOG)", modifier) {
        val kn = speedMps?.let { GeoMath.mpsToKnots(it.toDouble()) }
        BigNumber(if (kn == null) "--" else if (kn < 100) String.format(Locale.US, "%.1f", kn) else String.format(Locale.US, "%.0f", kn), bigSp)
        Text("knots", style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
private fun CourseCard(fix: GpsFix?, bigSp: androidx.compose.ui.unit.TextUnit, modifier: Modifier) {
    InfoCard("COURSE (COG)", modifier) {
        val b = fix?.bearingDeg
        BigNumber(if (b == null) "--" else String.format(Locale.US, "%03d°", b.roundToInt() % 360), bigSp)
        Text(
            when {
                b != null -> GeoMath.cardinal(b.toDouble())
                fix != null -> "too slow for course"
                else -> "no fix"
            },
            style = MaterialTheme.typography.titleMedium,
        )
    }
}

@Composable
private fun CoordsCard(fix: GpsFix?, live: Boolean, ageMs: Long?) {
    val title = when {
        fix == null -> "POSITION"
        live -> "POSITION"
        else -> "LAST KNOWN POSITION (${(ageMs ?: 0L) / 1000} s ago)"
    }
    InfoCard(title) {
        if (fix == null) {
            BigNumber("--", 32.sp)
            Text("No position yet. Nothing is shown until the GPS reports a real fix.", style = MaterialTheme.typography.bodyMedium)
        } else {
            CoordLine("LAT", GeoMath.formatDecimal(fix.lat, true), GeoMath.formatDegMin(fix.lat, true))
            Spacer(Modifier.height(8.dp))
            CoordLine("LON", GeoMath.formatDecimal(fix.lon, false), GeoMath.formatDegMin(fix.lon, false))
        }
    }
}

@Composable
private fun CoordLine(label: String, decimal: String, degMin: String) {
    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(end = 12.dp))
        Column {
            Text(decimal, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Text(degMin, fontFamily = FontFamily.Monospace, fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun TripCard(trip: TripSnapshot, onReset: () -> Unit) {
    InfoCard("TRIP") {
        val nm = GeoMath.metersToNm(trip.distanceM)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Stat("Distance", String.format(Locale.US, "%.2f NM", nm))
            Stat("Average", String.format(Locale.US, "%.1f kn", GeoMath.mpsToKnots(trip.avgSpeedMps)))
            Stat("Maximum", String.format(Locale.US, "%.1f kn", GeoMath.mpsToKnots(trip.maxSpeedMps)))
        }
        Spacer(Modifier.height(4.dp))
        Text(
            "Average is distance divided by time spent moving. Statistics only count while the app is open.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(12.dp))
        BigButton("Reset trip", outlined = true, onClick = onReset)
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 20.sp)
    }
}

@Composable
private fun TimeStatusCard(fix: GpsFix?, wallMs: Long, state: GpsUiState) {
    val local = SimpleDateFormat("HH:mm:ss", Locale.US)
    val utc = SimpleDateFormat("HH:mm:ss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
    InfoCard("TIME AND SIGNAL") {
        Stat("Local time", local.format(Date(wallMs)))
        Spacer(Modifier.height(8.dp))
        Stat("GPS time (UTC)", if (fix == null) "--" else utc.format(Date(fix.timeUtcMs)))
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Stat("Accuracy", fix?.accuracyM?.let { "±${it.roundToInt()} m" } ?: "--")
            Stat(
                "Satellites",
                if (state.satUsed != null && state.satVisible != null) "${state.satUsed} used / ${state.satVisible} seen" else "n/a",
            )
        }
    }
}

@Composable
private fun InfoCard(title: String, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(2.dp, MaterialTheme.colorScheme.outline),
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(4.dp))
            content()
        }
    }
}

@Composable
private fun BigNumber(text: String, size: androidx.compose.ui.unit.TextUnit) {
    Text(text, fontSize = size, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, maxLines = 1)
}

@Composable
private fun BigButton(text: String, outlined: Boolean = false, onClick: () -> Unit) {
    val mod = Modifier.fillMaxWidth().heightIn(min = 56.dp)
    if (outlined) {
        OutlinedButton(onClick = onClick, modifier = mod, border = BorderStroke(2.dp, MaterialTheme.colorScheme.outline)) { Text(text, style = MaterialTheme.typography.titleMedium) }
    } else {
        Button(onClick = onClick, modifier = mod) { Text(text, style = MaterialTheme.typography.titleMedium) }
    }
}
